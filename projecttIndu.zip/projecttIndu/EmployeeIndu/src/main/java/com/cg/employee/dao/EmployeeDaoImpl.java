package com.cg.employee.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.employee.bean.Employee;
import com.cg.employee.repository.EmpRepository;
@Repository

public class EmployeeDaoImpl implements IEmployeeDao{
	@Autowired
	EmpRepository repository;

	@Override
	public Employee insertEmployee(Employee employee) {
		// TODO Auto-generated method stub
		repository.save(employee);
		return employee;
	}

	@Override
	public List<Employee> viewEmployee() {
		// TODO Auto-generated method stub
		
		return	repository.findAll();
		 
	}

	@Override
	public Employee deleteEmployee(String empId) {
		Employee employee = repository.findOne(empId);
		repository.delete(employee);
		return employee;
	}

	@Override
	public Employee updateEmployee(String empId,Employee employee) {
		// TODO Auto-generated method stub
		Employee employee1=repository.findOne(empId);
		employee.setempId(empId);
		repository.save(employee);
		return employee;
	}

	@Override
	public String deleteAllEmployee() {
		// TODO Auto-generated method stub
		repository.deleteAll();
		return "Records deleted";
	}

	@Override
	public Employee viewbyIDEmployee(String empId) {
		 
		
		return  repository.findOne(empId);
	}

}
