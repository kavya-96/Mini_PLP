package com.cg.employee.dao;

import java.util.List;

import com.cg.employee.bean.Employee;

public interface IEmployeeDao {

	Employee insertEmployee(Employee employee);

	List<Employee> viewEmployee();

	Employee deleteEmployee(String empId);

	Employee updateEmployee(String empId,Employee employee);

	String deleteAllEmployee();

	Employee viewbyIDEmployee(String empId);

}
