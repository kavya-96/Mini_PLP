package com.cg.expenseclaimdetailsmodule.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Size;

@Entity
public class ExpenseModule {
	
	@Id
	private String expenseCode;
	
	@Size(min=3,max=15,message="Expense type should be min of 3 and max of 15 !")
	private String expenseType;
	
	@Size(min=15,max=100,message="Expense Description should be min of 15 and max of 100 !")
	private String expenseDesc;
	public ExpenseModule() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ExpenseModule(String expenseCode, String expenseType,
			String expenseDesc) {
		super();
		this.expenseCode = expenseCode;
		this.expenseType = expenseType;
		this.expenseDesc = expenseDesc;
	}
	public String getExpenseCode() {
		return expenseCode;
	}
	public void setExpenseCode(String expenseCode) {
		this.expenseCode = expenseCode;
	}
	public String getExpenseType() {
		return expenseType;
	}
	public void setExpenseType(String expenseType) {
		this.expenseType = expenseType;
	}
	public String getExpenseDesc() {
		return expenseDesc;
	}
	public void setExpenseDesc(String expenseDesc) {
		this.expenseDesc = expenseDesc;
	}
	
	
	
	
}
