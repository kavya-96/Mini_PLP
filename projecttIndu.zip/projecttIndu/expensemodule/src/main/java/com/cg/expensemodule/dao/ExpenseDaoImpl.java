package com.cg.expensemodule.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.expensemodule.bean.ExpenseModule;
import com.cg.expensemodule.repository.ExpenseRepository;

@Repository
public class ExpenseDaoImpl implements IExpenseDao {
	@Autowired
	ExpenseRepository repository;

	@Override
	public ExpenseModule createExpenseModule(ExpenseModule expense) {
		// TODO Auto-generated method stub
		return repository.save(expense);
	}

	@Override
	public List<ExpenseModule> readExpenseModule() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public ExpenseModule deleteExpenseModule(String expenseCode) {
		ExpenseModule expenseModule =repository.findOne(expenseCode);
		 repository.delete(expenseModule);
		 return expenseModule;
		
		
	}

	@Override
	public ExpenseModule updateExpenseModule(String expenseCode, ExpenseModule expenseModule) {
		// TODO Auto-generated method stub
		repository.findOne(expenseCode);
		expenseModule.setExpenseCode(expenseCode);
		repository.save(expenseModule);
		return expenseModule;
	}

	@Override
	public ExpenseModule readExpenseModuleById(String expenseCode) {
		return repository.findOne(expenseCode);
	}

}
