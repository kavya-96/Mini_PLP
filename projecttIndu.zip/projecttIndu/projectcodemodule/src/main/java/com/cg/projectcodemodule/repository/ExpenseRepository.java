package com.cg.projectcodemodule.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.projectcodemodule.bean.ProjectBean;

public interface ExpenseRepository extends JpaRepository<ProjectBean, String> {
	
	

	
}
