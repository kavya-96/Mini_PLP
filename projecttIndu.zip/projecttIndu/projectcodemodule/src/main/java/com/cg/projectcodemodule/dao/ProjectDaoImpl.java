package com.cg.projectcodemodule.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.projectcodemodule.bean.ProjectBean;
import com.cg.projectcodemodule.exception.UserNotFoundException;
import com.cg.projectcodemodule.repository.ExpenseRepository;

@Repository
public class ProjectDaoImpl implements IProjectDao{
	
	@Autowired
	ExpenseRepository repository;

	@Override
	public ProjectBean insertProjectDetails(ProjectBean projectBean) {
		long startDateSecs=projectBean.getStartDate().getTime();
		long endDateSecs=projectBean.getEndDate().getTime();
		long diff=startDateSecs-endDateSecs;
		if(diff>=0){
			throw new UserNotFoundException("End date should be greater than start date");
		}
		
		return repository.save(projectBean);
	}

	@Override
	public List<ProjectBean> viewProjectDetails() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public ProjectBean viewProjectDetailsByCode(String projectCode) {
		// TODO Auto-generated method stub
		return repository.findOne(projectCode);
	}

	@Override
	public ProjectBean deleteProjectDetailsByCode(String projectCode) {
		// TODO Auto-generated method stub
		ProjectBean projectBean = repository.findOne(projectCode);
		repository.delete(projectBean);
		return projectBean;
	}

	@Override
	public ProjectBean updateProjectDetails(String projectCode,ProjectBean projectBean) {
		 repository.findOne(projectCode);
		 projectBean.setProjectCode(projectCode);
		 repository.save(projectBean);
		return projectBean;
	}

}
